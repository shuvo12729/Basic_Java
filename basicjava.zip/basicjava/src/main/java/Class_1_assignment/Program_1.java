package Class_1_assignment;

public class Program_1 {

    public static void main(String[] args) {


        /*1. Write a program to set your name and university in variables and print in this format:
        "Hello, I am ____. I passed from ___ university. "*/

        String name = "Shuvo";
        String university = "World";
        System.out.println("Hello, I am "+name+ " I Passed from "+university+" University");
    }
}
