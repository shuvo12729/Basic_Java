package Class_4_assignment;

public class Program_6 {
    public static void main(String[] args) {


        /*6. Write a program that will show minimum number of currency notes to sum of given amount. For example: You input an amount 1400. The output will be:
        1000 1
        200 2
        Or you input the amount 165. The output will be:
        100 1
        50 1
        10 1
        5 1*/


    }
}
