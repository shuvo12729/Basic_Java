package Class_4_assignment;

import java.util.Random;
import java.util.Scanner;

public class Program_4 {

    public static void main(String[] args) {

        /*Write a program to find the position of a matched value from an array. If not matched, return -1 using function.
        Given array is: {10,5,2,3,2,7,7,15,10}
        Input: User inputs 7
        Output: Position: 5*/





    }
}
